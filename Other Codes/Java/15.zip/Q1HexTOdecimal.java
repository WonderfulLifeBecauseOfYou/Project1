import java.util.Scanner;

public class Q1HexTOdecimal {

	public static void main(String[] args) {
		//4
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a two digits hex number: ");
		String hex = input.next();
		
		if (hex.length() != 2) {
			System.out.print(hex + " is an invalid input.");
			System.exit(1);
		}//4
		
		int digit1 = 0, digit2 = 0;
		char d1 = hex.toUpperCase().charAt(0);//4
		if ('A' <= d1 && d1 <= 'F') {
			digit1 = d1 - 55;
		} else if ('0' <= d1 && d1 <= '9') {
			digit1 = d1 - '0';
		} else {
			System.out.print(hex + " is an invalid input.");
			System.exit(1);
		}

		char d2 = hex.toUpperCase().charAt(1);//4
		if ('A' <= d2 && d2 <= 'F') {
			digit2 = d2 - 55;
		} else if ('0' <= d2 && d2 <= '9') {
			digit2 = d2 - '0';
		} else {
			System.out.print(hex + " is an invalid input.");
			System.exit(1);
		}
		
		System.out.print("The decimal value is " + (digit1 * 16 + digit2));//4

	}

}
