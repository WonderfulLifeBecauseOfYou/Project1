import java.util.Scanner;

public class Q2convertCSTtoJava {

	public static void main(String[] args) {
		// 5
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a string: ");
		String str = input.nextLine();
		if (str.length() < 3) {//5
			System.out.print(str);
		} else if (str.length() == 3) {//5
			if (str.equals("CST")) {
				System.out.print("Java");
			} else {
				System.out.print(str);
			}
			
		} else {//5
			if (str.substring(0, 3).equals("CST")) {
				System.out.print("Java" + str.substring(3, str.length()));
			} else if (str.substring(1, 4).equals("CST")) {
				System.out.print(str.charAt(0) + "Java" + str.substring(4, str.length()));
			} else {
				System.out.print(str);
			}
		}
	}

}
