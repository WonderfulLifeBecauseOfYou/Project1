/**
 * 
 */

/**
 * @author DELL
 *
 */
public class Circle2D {
private double x;
private double y;
private double radius;
	/**
	 * 
	 */
	public Circle2D() {
		// TODO Auto-generated constructor stub
		this.x=0;
		this.y=0;
		this.radius=1;
	}
	public Circle2D(double x,double y,double radius) {
		// TODO Auto-generated constructor stub
		this.x=x;
		this.y=y;
		this.radius=radius;
	}
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	public double getR() {
		return radius;
	}
	public double getPerimeter() {
		return 2*Math.PI*radius;
	}
	public double getArea() {
		return Math.PI*radius*radius;
	}
	public boolean contains(double x, double y) {
		return Math.pow((Math.pow((x-this.x),2)+Math.pow((y-this.y),2)),1/2)<this.radius;
	}
	public boolean contains(Circle2D circle) {
		return 2*Math.pow((Math.pow((circle.x-this.x),2)+Math.pow((circle.y-this.y),2)),1/2)+circle.radius<this.radius;
	}
	public boolean overlaps(Circle2D circle) {
		return Math.pow((Math.pow((circle.x-this.x),2)+Math.pow((circle.y-this.y),2)),1/2)<this.radius+circle.radius;
	}
	
	
}
