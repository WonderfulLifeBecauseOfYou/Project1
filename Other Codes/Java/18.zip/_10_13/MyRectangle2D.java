
public class MyRectangle2D {

	public MyRectangle2D() {
		// TODO Auto-generated constructor stub
		this.x = 0;
		this.y = 0;
		this.height = 1;
		this.width = 1;
	}
	private double x;
	private double y;
	private double width;
	private double height;
	public MyRectangle2D(double x, double y, double width, double height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public double getArea() {
		return height * width;
	}

	public double getPerimeter() {
		return (height + width) * 2;
	}

	public boolean contains(double x, double y) {
		return Math.abs(x - this.x) < width / 2 && Math.abs(y - this.y) < height / 2;
	}

	public boolean contains(MyRectangle2D r) {
		return Math.abs(this.x - r.getX()) <= Math.abs((this.width - r.width) / 2)
				&& Math.abs(this.y - r.y) <= Math.abs((this.height - r.height) / 2);
	}

	public boolean overLaps(MyRectangle2D r) {
		boolean overlaps1 = Math.abs(this.x - r.getX()) > Math.abs((this.width - r.width) / 2)
				&& Math.abs(this.y - r.y) > Math.abs((this.height - r.height) / 2);
		boolean overlaps2 = Math.abs(this.x - r.getX()) < Math.abs((this.width + r.width) / 2)
				&& Math.abs(this.y - r.y) < Math.abs((this.height + r.height) / 2);
		return overlaps1 && overlaps2;
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

}
