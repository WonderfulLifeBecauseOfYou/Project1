
public class Time {
private int hour;
private int minute;
private int second;
	public Time() {
		// TODO Auto-generated constructor stub
		long t = System.currentTimeMillis();
		long seconds = t/1000;
		second = (int)second%60;
		seconds/=60;
		minute = (int)seconds%60;
		seconds/=60;
		hour = (int)seconds%24;
	}
	public Time(int t) {
		int seconds = t/1000;
		second = (int)second%60;
		seconds/=60;
		minute = (int)seconds%60;
		seconds/=60;
		hour = (int)seconds%24;
	}
	int getHour() {
		return hour;
	}
	int getMinute() {
		return minute;
	}
	int getSecond() {
		return second;
	}
	public void setTime(long elapseTime) {
		long seconds=elapseTime/1000;
		second = (int)second%60;
		seconds/=60;
		minute = (int)seconds%60;
		seconds/=60;
		hour = (int)seconds%24;
	}
	
}
