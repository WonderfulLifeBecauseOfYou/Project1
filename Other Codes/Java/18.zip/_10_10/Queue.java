

public class Queue {
	private int[] elements;
	private int size;
	public Queue() {
		// TODO Auto-generated constructor stub
		int capacity=8;
		int[] elements=new int[capacity-1];
	}
	public Queue(int capacity) {
		int[] elements=new int[capacity];
	}
	public void enqueue(int v) {
		if(size>elements.length) {
			int[] element2=new int[elements.length*2];
			elements=element2;
		}
		elements[size]=v;
		size++;
	}
	public int[] dequeue() {
		for(int i=0;i<size;i++) {
			elements[i]=elements[i+1];
		}
		return elements;
	}
	public boolean empty() {
		return size==0;
	}
	int getSize() {
		return size;
	}

}
