/**
 * 
 */

/**
 * @author DELL
 *
 */
public class _10_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue queue=new Queue();
		for(int i=0;i<20;i++) {
			queue.enqueue(i);
			while(!queue.empty()) {
				System.out.print(queue.dequeue()+" ");
			}
		}

	}

}
