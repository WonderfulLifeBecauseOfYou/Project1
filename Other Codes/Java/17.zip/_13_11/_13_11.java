/**
 * 
 */

/**
 * @author DELL
 *
 */
public class _13_11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Octagon o1 = new Octagon(2);
		Octagon o2 = (Octagon)o1.clone();
	    System.out.println(o1.getArea());
	    if (o1.compareTo(o2)==0)
	    	System.out.println("True");
		else 
			System.out.println("False"); 
	}

}
