
public abstract class GeometricObject {

	public GeometricObject() {
		// TODO Auto-generated constructor stub
	}


public abstract double getArea();
public abstract double getPerimeter();
}
