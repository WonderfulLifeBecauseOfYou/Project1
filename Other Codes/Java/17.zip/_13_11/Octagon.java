
public class Octagon extends GeometricObject implements Comparable< Octagon >, Cloneable {
	private double side;
	public Octagon() {
		// TODO Auto-generated constructor stub
	}
	public Octagon(double side) {
		this.side=side;
	}
	public double getSide() {
		return side;
	}
	public void setSide(double side) {
		this.side = side;
	}
	public double getArea() {
		return (2 + 4 * Math.sqrt(2)) * side * side;
	}
	public double getPerimeter() {
		return 8 * side;
	}
	public String toString() {
		return super.toString() + "\nside : " + side;
	}
	public int compareTo(Octagon o) {
		if (getArea() > o.getArea())
			return 1;
		else if (getArea() < o.getArea())
			return -1;
		else
			return 0;
	}
	public Object clone() {
		try {
			Octagon octagon = (Octagon) super.clone();
			return octagon;
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}
}
