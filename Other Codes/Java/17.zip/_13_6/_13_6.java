/**
 * 
 */

/**
 * @author DELL
 *
 */
public class _13_6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ComparableCircle c1 = new ComparableCircle(1.0);
		ComparableCircle c2 = new ComparableCircle(10.0);
		if (c1.compareTo(c2) > 0)
			System.out.println("c1 > c2");
		else if (c1.compareTo(c2) == 0)
			System.out.println("c1 = c2");
		else
			System.out.println("c1 < c2");
	}
}
