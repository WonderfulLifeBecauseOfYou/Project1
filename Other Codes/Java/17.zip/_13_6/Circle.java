/**
 * 
 */

/**
 * @author DELL
 *
 */
public class Circle {
    private double radius=1.0;
	/**
	 * 
	 */
	public Circle() {
		// TODO Auto-generated constructor stub
		radius=1.0;
	}
	public Circle(double radius) {
		this.radius=radius;
	}
	public double getArea() {
		return radius*radius*Math.PI;
	}

}
