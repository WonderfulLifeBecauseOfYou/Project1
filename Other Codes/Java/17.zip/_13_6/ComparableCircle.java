/**
 * 
 */

/**
 * @author DELL
 *
 */
public class ComparableCircle extends Circle implements Comparable{
	/**
	 * 
	 */
	public ComparableCircle() {
		// TODO Auto-generated constructor stub
		super();
	}
	public ComparableCircle(double radius) {
		super(radius);
	}
	public int compareTo(ComparableCircle o) {
		if (this.getArea() > o.getArea()) {
			return 1;
		} else if (this.getArea() < o.getArea()) {
			return -1;
		} else {
			return 0;
		}
}
	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}
}
