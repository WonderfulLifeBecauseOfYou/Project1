/**
 * 
 */
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _13_7 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
	    GeometricObject[] squares = new Square[5];
	    for (int i = 0; i < 5; i++) {
	        System.out.println(i + ":Square ");
	        System.out.print("\tEnter width: ");
	        double width = input.nextDouble();
	        System.out.print("\tEnter height: ");
	        double height = input.nextDouble();
	        System.out.print("\tEnter Color: ");
	        String color = input.next();
	        System.out.print("\tIs Filled: ");
	        boolean filled = input.nextBoolean();
	        squares[i] = new Square(width, height, color, filled);
	        for (int a = 0; a < 5; a ++) {
		        System.out.println(squares[i].toString());
		        System.out.println();
		    }
	    }

	}

}
