
public class Square extends GeometricObject implements Colorable{
	private double width;
	private double height;
	public Square() {
		// TODO Auto-generated constructor stub
	}
	public Square(double width, double height, String color, boolean filled) {
	    super(color, filled);
	    this.width = width;
	    this.height = height;
	}
	public double getArea() {
	    return width * height;
	}
	public void howToColor(){
		System.out.println("Color all four sides");
	}
	public String toString(){
		if(isFilled()) {
			howToColor();}
		return super.toString();
	}
	
}
