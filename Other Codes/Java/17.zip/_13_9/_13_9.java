/**
 * 
 */

/**
 * @author DELL
 *
 */
public class _13_9 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle c1 = new Circle(1);
		Circle c2 = new Circle(10);
		Circle c3 = new Circle(1);
		System.out.println("c1 equals c2 ? " + c1.equals(c2));
		System.out.println("c1 equals c3 ? " + c1.equals(c3));
	}

}
