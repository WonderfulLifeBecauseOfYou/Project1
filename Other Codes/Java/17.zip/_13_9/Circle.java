/**
 * 
 */

/**
 * @author DELL
 *
 */
public class Circle extends GeometricObject implements Comparable< Circle >{
	private double radius;
	/**
	 * 
	 */
	public Circle() {
		// TODO Auto-generated constructor stub
	}
	public Circle(double radius) {
		this(radius, "white", false);
	}

	public Circle(double radius, String color, boolean filled) {
		super(color, filled);
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public double getArea() {
		return radius * radius * Math.PI;
	}

	public String toString() {
		return "\nCircle Radius : " + getRadius();
	}

	public int compareTo(Circle c) {
		if (getArea() < c.getArea())
			return -1;
		else if (getArea() > c.getArea())
			return 1;
		else
			return 0;
	}

	public boolean equals(Object o) {
		if (((Circle) o).getRadius() == radius)
			return true;
		else
			return false;
	}
}
