/**
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _11_12 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.print("Enter 5 doubles: ");
			Scanner input = new Scanner(System.in);
			ArrayList<Double> list = new ArrayList<>();
			for (int i = 0; i < 5; i++) {
				double n = input.nextDouble();
				list.add(n);
			}
			double sum = sum(list);
			System.out.println("The sum is " + sum(list));
		}
		public static double sum(ArrayList<Double> list) {
			double n1 = 0;
			for (double n2 : list)
				n1 += n2;
			return n1;
		}

	}
