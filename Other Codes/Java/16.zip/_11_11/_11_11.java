/**
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _11_11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.print("Enter 5 integers: ");
			Scanner input = new Scanner(System.in);
			ArrayList<Integer> list = new ArrayList<>();
			for (int i = 0; i < 5; i++) {
				Integer n = input.nextInt();
				list.add(n);
			}
			sort(list);
			for (int i = 0; i < 5; i++)
				System.out.println(list.get(i));
		}
		public static void sort(ArrayList<Integer> list) {
			java.util.Collections.sort(list);
		}

	}
