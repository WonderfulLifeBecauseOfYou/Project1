/**
 * 
 */
import java.util.Date;
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _11_1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("Enter three sides: ");
		double side1 = input.nextDouble();
		double side2 = input.nextDouble();
		double side3 = input.nextDouble();
		System.out.println("Enter color: ");
		String a = input.next();
		System.out.println("Enter filled: ");
		boolean filled = input.nextBoolean();
		Triangle b = new Triangle(side1, side2, side3);
		b.setColor(a);
		b.setFilled(filled);
		System.out.println("The area:" + b.getArea());
		System.out.println("The perimeter:" + b.getPerimeter());
		System.out.println("The color:" + b.getColor());
		System.out.println("The filled:" + b.isFilled());
	}

}
