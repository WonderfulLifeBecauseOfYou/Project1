/**
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _11_4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.print("Enter numbers (0 finished): ");
			Scanner input = new Scanner(System.in);
			ArrayList<Integer> list = new ArrayList<Integer>();
			int n = input.nextInt();
			while (n != 0) {
				list.add(n);
				n = input.nextInt();
			}
			System.out.println("The maximum is " + max(list));
		}
		public static Integer max(ArrayList<Integer> list) {
			if (list == null || list.size() == 0)
				return null;
			else
				return java.util.Collections.max(list);
		}

	}
