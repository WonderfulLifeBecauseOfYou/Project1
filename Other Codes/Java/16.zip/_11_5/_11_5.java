/**
 * 
 */
import java.util.ArrayList;
import java.util.List;
/**
 * @author DELL
 *
 */
public class _11_5 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Course course1 = new Course();
		course1.addStudents("Peter Jones");
		course1.addStudents("Kim Smith");
		course1.addStudents("Anne Kennedy");
		List<String> students = course1.getStudents();
		System.out.println("Number of students in course1: " + students.size());
		System.out.print(students.get(0));
		for (int i = 1; i < students.size(); i++) {
			System.out.print(", " + students.get(i));
		}
		course1.dropStudents("Peter Jones");
		System.out.println("\nNumber of students in course1: " + students.size());
		System.out.print(students.get(0));
		for (int i = 1; i < students.size(); i++) {
			System.out.print(", " + students.get(i));
		}
	}

	}
