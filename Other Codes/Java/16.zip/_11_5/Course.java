/**
 * 
 */

/**
 * @author DELL
 *
 */
public class Course {
	private String courseName;
	private java.util.ArrayList<String> students = new java.util.ArrayList<String>();
	private int numOfStudents;
	public void Course() {
		this.courseName = courseName;
	}
	public String getCourseName() {
		return courseName;
	}

	public void addStudents(String student) {
		students.add(student);
	}

	public java.util.ArrayList<String> getStudents() {
		return students;
	}

	public int getNumberOfStudents() {
		return students.size();
	}

	public void dropStudents(String student) {
		students.remove(student);
	}

	public void clear() {
		students.clear();
	}
}
