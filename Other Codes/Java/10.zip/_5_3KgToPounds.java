/**
 * 
 */

/**
 * @author Zhicheng YIN
 *
 */
public class _5_3KgToPounds {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("Kilograms\tPounds");
		// while loop
		int kilograms = 1;
		while (kilograms < 200) {
			System.out.printf("%d\t\t%6.1f\n", kilograms, kilograms * 2.2);
			kilograms += 2;
		}
		
		
		System.out.println("Kilograms\tPounds");
		// for loop
		for (int kilograms1 = 1; kilograms1 < 200; kilograms1 += 2) {
			System.out.printf("%d\t\t%6.1f\n", kilograms1, kilograms1 * 2.2);
		}
		
		
		System.out.println("Kilograms\tPounds");
		// do-while loop
		int kilograms2 = 1;
		do {
			System.out.printf("%d\t\t%6.1f\n", kilograms2, kilograms2 * 2.2);
			kilograms2 += 2;
		} while (kilograms2 < 200);
	}

}
