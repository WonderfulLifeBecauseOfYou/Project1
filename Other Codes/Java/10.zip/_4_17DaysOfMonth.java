import java.util.Scanner;

/**
 * 
 */

/**
 * @author Zhicheng YIN
 *
 */
public class _4_17DaysOfMonth {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a year: ");
		int year = input.nextInt();

		System.out.print("Enter a month: ");
		String month = input.next().toLowerCase();

		if (month.equals("jan") || month.equals("mar") 
				|| month.equals("may") || month.equals("jul")
				|| month.equals("aug") || month.equals("oct") 
				|| month.equals("dec")) {
			
			System.out.print(month + " " + year + " has 31 days");
			
		} else if (month.equals("apr") || month.equals("jun") 
				|| month.equals("sep") || month.equals("nov")) {
			
			System.out.print(month + " " + year + " has 30 days");
			
		} else if (month.equals("feb")) {
			
			if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
				
				System.out.print(month + " " + year + " has 29 days");
				
			} else {
				
				System.out.print(month + " " + year + " has 28 days");
				
			}
			
		} else {
			
			System.out.print(month + " is not a correct month name ");
			
		}
	}

}
