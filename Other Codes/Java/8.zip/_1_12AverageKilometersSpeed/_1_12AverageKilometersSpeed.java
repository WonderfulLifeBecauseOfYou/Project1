/**
 * This program is to compute the average speed in kilometers
 */

/**
 * @author zhicheng.yin
 *
 */
public class _1_12AverageKilometersSpeed {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double miles = 24;
		double time = 1 + 40 / 60.0 + 35 / 60.0 / 60;
		double speed = 24 * 1.6 / time;
		System.out.print("The average speed in kilometers per hour is " + speed);
	}

}
