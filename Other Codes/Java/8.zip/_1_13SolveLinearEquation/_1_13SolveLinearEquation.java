/**
 * This program is solving 2X2 linear equations by using Cramer's rule.
 */

/**
 * @author zhicheng.yin
 *
 */
public class _1_13SolveLinearEquation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("x is ");
		System.out.println((44.5 * 0.55 - 50.2 * 5.9) / (3.4 * 0.55 - 50.2 * 2.1));

		System.out.print("y is ");
		System.out.println((3.4 * 5.9 - 44.5 * 2.1) / (3.4 * 0.55 - 50.2 * 2.1));
	}

}
