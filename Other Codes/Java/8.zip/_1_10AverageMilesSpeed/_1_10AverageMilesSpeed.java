/**
 * This program is to compute the average speed in miles.
 */

/**
 * @author zhicheng.yin
 *
 */
public class _1_10AverageMilesSpeed {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println((14 / 45.5) * 60 / 1.6);

		double km = 14;
		double min = 45;
		double sec = 30;
		double hour = (min + sec / 60) / 60;
		double kmPerh = km / hour;
		double mPerh = kmPerh / 1.6;
	
		System.out.print("The avaerage speed in miles per hour is " + mPerh);

	}

}
