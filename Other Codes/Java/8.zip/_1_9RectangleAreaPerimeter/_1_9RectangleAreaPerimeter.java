/**
 * This program is to compute area & perimeter of a rectangle.
 */

/**
 * @author zhicheng.yin
 * @date 28/10/2020
 */
public class _1_9RectangleAreaPerimeter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double width = 4.5;
		double height = 7.9;
		double area = width*height;
		double perimeter = (width+height)*2;
		System.out.print("area & perimeter of a rectangle is "+area+", "+ perimeter);
	}

}
