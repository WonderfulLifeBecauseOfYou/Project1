/**
 * This program is to estimate the population of 5 years with following assumption:
 * One birth every 7 seconds
 * One death every 13 seconds
 * One new immigrant every 45 seconds
 */

/**
 * @author zhicheng.yin
 *
 */
public class _1_11PopulationProjection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long currentPop = 312032486;
		double secInYear = 60 * 60 * 24 * 365;

		double year1 = currentPop + secInYear / 7 - secInYear / 13 + secInYear / 45;
		double year2 = year1 + secInYear / 7 - secInYear / 13 + secInYear / 45;
		double year3 = year2 + secInYear / 7 - secInYear / 13 + secInYear / 45;
		double year4 = year3 + secInYear / 7 - secInYear / 13 + secInYear / 45;
		double year5 = year4 + secInYear / 7 - secInYear / 13 + secInYear / 45;
		System.out.printf("year 1: %.3f\n", year1);
		System.out.printf("year 2: %.3f\n", year2);
		System.out.printf("year 3: %.3f\n", year3);
		System.out.printf("year 4: %.3f\n", year4);		
		System.out.printf("year 5: %.3f\n", year5);
		
	}

}
