/**
 * 
 */

/**
 * @author Zhicheng YIN
 *
 */
public class _2_2ComputeCylinderVolume {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);

		System.out.print("Enter the radius and length of a cylinder: ");
		double radius = input.nextDouble();
		double length = input.nextDouble();

		System.out.printf("The area of base is %.4f\n", (radius * radius * Math.PI));
		System.out.printf("The volume is %.1f\n", (length * radius * radius * Math.PI));
		System.out.printf("The Surface area is %.4f", (radius * radius * Math.PI * 2 + length * 2 * radius * Math.PI));

	}

}
