/**
 * 
 */

/**
 * @author Zhicheng YIN
 *
 */
public class _2_10CalculateEnergy {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);
		System.out.print("Enter the amount of water in kilograms: ");
		double m = input.nextDouble();
		System.out.print("Enter the initial temperature: ");
		double initialTemp = input.nextDouble();
		System.out.print("Enter the final temperature: ");
		double finalTemp = input.nextDouble();
		double q = m * (finalTemp - initialTemp) * 4184;
		System.out.print("The energy needed is "+ q);
	}

}
