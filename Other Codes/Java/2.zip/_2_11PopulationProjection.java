/**
 * 
 */

/**
 * @author Zhicheng YIN
 *
 */
public class _2_11PopulationProjection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);
		System.out.print("Enter the number of years: ");

		int numberOfYears = input.nextInt();

		double population = 312032486 + numberOfYears * 365 * 24 * 60 * 60 / 7.0
				- numberOfYears * 365 * 24 * 60 * 60 / 13.0 + numberOfYears * 365 * 24 * 60 * 60 / 45.0;

		// Display results
		System.out.println("The population in " + numberOfYears + " years is " + (int) population);

	}

}
