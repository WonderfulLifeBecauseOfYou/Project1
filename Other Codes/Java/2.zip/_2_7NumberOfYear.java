/**
 * 
 */

/**
 * @author zhicheng YIN
 *
 */
public class _2_7NumberOfYear {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);
		System.out.print("Enter the number of minutes: ");
		long minutes = input.nextLong();
		long years = minutes / 60 / 24 / 365;
		long days = minutes / 60 / 24 - years * 365;
		System.out.print(minutes + " minutes is approximately " + years + " years and " + days + " days");

	}

}
