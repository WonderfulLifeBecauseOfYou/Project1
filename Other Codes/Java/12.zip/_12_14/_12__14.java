/**
 * 
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _12__14 {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		
			Scanner input1 = new Scanner(System.in);
			System.out.print("Enter a name of file: ");
			String strName = input1.nextLine();
			File file = new File(strName);
			if (!file.exists()) {
				System.out.println("Not Exists!");
				System.exit(1);
			}
			double sum = 0;
			int count = 0;
			Scanner input2 = new Scanner(file);
			while (input2.hasNext()) {
				sum += input2.nextDouble();
				input2.skip(" ");
				count++;
			}
			input1.close();
			input2.close();
			System.out.println("The sum is " + sum);
			System.out.println("Average is " + (sum / count));
		}

}
