/**
 * 
 */
import java.util.Scanner;
/**
 * @author DELL
 *
 */
public class _12__3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner input = new Scanner(System.in);
			int[] n = new int[100];
			for (int i = 0; i < n.length; i++)
				n[i] = (int) (Math.random() * 100);
			System.out.print("Enter your index: ");
			int index = input.nextInt();
			try {
				int n1 = n[index];
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Out of bounds!");
				System.exit(1);
			}
			System.out.println("The number of the index is " + n[index]);
		}

	}
