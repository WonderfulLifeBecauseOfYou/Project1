/**
 * 
 */
import java.util.Scanner;
import java.util.InputMismatchException;
/**
 * @author DELL
 *
 */
public class _12__2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner input=new Scanner(System.in);
    boolean f=true;
    do {
    try {
    System.out.print("Enter two integers: ");
    int n1=input.nextInt();
    int n2=input.nextInt();
    int s=n1+n2;
    System.out.println("The sum is: "+s);
    f=false;
    }
    catch(InputMismatchException ex) {
    	System.out.println("Read the number again.");
    	input.nextLine();
    }
	}while(f);
	}
}
