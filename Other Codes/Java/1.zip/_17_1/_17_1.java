import java.io.File;
import java.io.PrintWriter;
import java.io.IOException;

public class _17_1{
    public static void main(String[] args) throws IOException{
        File file = new File("Exercise17_01.txt");  
        try(
            PrintWriter write = new PrintWriter(file);
        ){
            for (int i = 0; i < 100; i++){
                int random = (int)(Math.random() * 100);
                write.print(random + " ");
            }
        }
    }
}
