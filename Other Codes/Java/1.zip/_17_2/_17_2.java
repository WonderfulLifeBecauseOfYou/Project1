import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class _17_2{
    public static void main(String[] args) throws IOException{
        try(
            FileOutputStream output = new FileOutputStream("Exercise17_02.dat");    
        ){
            int random = 0;
            for (int i = 0; i < 100; i++) {
                random = (int)(Math.random() * 100);
                output.write(random);
            }
        }

        try(
            FileInputStream input = new FileInputStream("Exercise17_02.dat");   
        ){
            for (int i = 0; i< 100; i++){
                System.out.print(input.read() + " ");
            }System.out.println();
        }
    }
}
