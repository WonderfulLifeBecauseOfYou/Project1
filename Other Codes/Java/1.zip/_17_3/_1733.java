import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.EOFException;

public class _1733{
    public static void main(String[] args){
        int sum = 0;
        try{
            try(
                DataInputStream input = new DataInputStream(
                    new FileInputStream("Exercise17_03.dat"));  
            ){
                while (true){
                    sum += input.readInt();
                }
            }
        }
        catch (EOFException ex){
            System.out.println(sum);
            System.out.println("�Ѿ�������β");
        }
        catch (IOException ex){
            ex.printStackTrace();
        }

    }
}