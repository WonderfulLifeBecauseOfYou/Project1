import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class _17_3{
    public static void main(String[] args) throws IOException{
        try(
            DataOutputStream output = new DataOutputStream(
            new FileOutputStream("Exercise17_03.dat")); 
        ){
            int random = 0;
            for (int i = 0; i < 100; i++){
                random = (int)(Math.random() * 1000);
                output.writeInt(random);
            }
        }
    }
}