import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;

public class _17_5{
    public static void main(String[] args) throws ClassNotFoundException, IOException{
        try(
            ObjectOutputStream output = new ObjectOutputStream(
                new FileOutputStream("object1.dat"));
        ){
            int[] numbers = {1, 2, 3, 4, 5};
            double d = 5.5;
            Date date = new Date();
            output.writeObject(numbers);
            output.writeDouble(d);
            output.writeObject(date);
        }

        try(
            ObjectInputStream input = new ObjectInputStream(
                new FileInputStream("object1.dat"));    
        ){
            int[] getNum = (int[])(input.readObject());
            int length = getNum.length;
            for (int i = 0; i < length; i++){
                System.out.print(getNum[i] + " ");
           }System.out.println();
            System.out.println(input.readDouble());
            System.out.println((Date)(input.readObject()));
        }
    }
}