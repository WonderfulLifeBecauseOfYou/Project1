import java.util.Scanner;

/**
 * 
 */

/**
 * @author zhicheng.yin
 *
 */
public class _4_11DecimalToHex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a decimal value (0 to 15): ");
		int decimal = input.nextInt();

		if (decimal > 15 || decimal < 0)
			System.out.println(decimal + " is an invalid input");
		else if (decimal < 10)
			System.out.println("The hex value is " + decimal);
		else
			System.out.println("The hex value is " + (char) ('A' + decimal - 10));

	}

}
