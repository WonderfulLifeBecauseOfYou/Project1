/**
 * 
 */

/**
 * @author zhicheng.yin
 *
 */
public class _4_8ASCIIcode {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		java.util.Scanner input = new java.util.Scanner(System.in);

		// Enter an ASCII code
		System.out.print("Enter an ASCII code: ");
		int code = input.nextInt();

		// Display result
		System.out.println("The character for ASCII code " + code + " is " + (char) code);
	}

}
