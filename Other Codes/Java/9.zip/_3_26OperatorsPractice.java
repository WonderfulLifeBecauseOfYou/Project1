import java.util.Scanner;

/**
 * 
 */

/**
 * @author zhicheng.yin
 *
 */
public class _3_26OperatorsPractice {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.print("Enter an integer: ");
		int num = input.nextInt();
		System.out.print("Is " + num + "divisible by 5 and 6? ");
		System.out.println(num % 5 == 0 && num % 6 == 0);

		System.out.print("Is " + num + "divisible by 5 or 6? ");
		System.out.println(num % 5 == 0 || num % 6 == 0);

		System.out.print("Is " + num + "divisible by 5 or 6, but not both? ");
		System.out.println(num % 5 == 0 ^ num % 6 == 0);

	}

}
