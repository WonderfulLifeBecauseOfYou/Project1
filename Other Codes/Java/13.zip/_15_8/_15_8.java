import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
public class _15_8 extends Application{
	public void start(Stage primaryStage){
       Pane pane = new Pane();
       Text coordinate = new Text();
       pane.setOnMousePressed(e -> {
           double x = e.getX();
           double y = e.getY();
           coordinate.setX(x);
           coordinate.setY(y);
           coordinate.setText("(" + x + "," + y + ")");
           pane.getChildren().add(coordinate);
       });

       pane.setOnMouseReleased(e -> {
           pane.getChildren().remove(coordinate);
       });
       Scene scene = new Scene(pane);
       primaryStage.setTitle("ShowMouseCoordinate");
       primaryStage.setScene(scene);
       primaryStage.show();
   }
}
