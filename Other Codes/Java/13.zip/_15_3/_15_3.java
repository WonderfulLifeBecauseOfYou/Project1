import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
public class _15_3 extends Application{
	public void start(Stage primaryStage){
       Pane pane = new Pane();
       Circle circle = new Circle(10, 10, 10);
       circle.setFill(Color.WHITE);
       circle.setStroke(Color.BLACK);
       pane.getChildren().add(circle);
       Button up = new Button("Up");
       Button right = new Button("Right");
       Button down = new Button("Down");
       Button left = new Button("Left");
       HBox hbox = new HBox(5);
       hbox.setAlignment(Pos.CENTER);
       hbox.getChildren().addAll(up, right, down, left);
       pane.getChildren().add(hbox);
       up.setOnAction(e -> {
           if (circle.getCenterY() - 10 - 5 < 0){
                circle.setCenterY(circle.getCenterY());
            }
            else 
               circle.setCenterY(circle.getCenterY() - 5);
               circle.setCenterX(circle.getCenterX());
            });
        down.setOnAction(e -> {
            if (circle.getCenterY() + 10 + 5 > pane.getHeight()){
                circle.setCenterY(circle.getCenterY());
            }
            else 
               circle.setCenterY(circle.getCenterY() + 5);
               circle.setCenterX(circle.getCenterX());
            });
        left.setOnAction(e -> {
            if (circle.getCenterX() - 10 - 5 < 0){
                circle.setCenterX(circle.getCenterX()); 
            }
            else 
               circle.setCenterX(circle.getCenterX() - 5);
               circle.setCenterY(circle.getCenterY());
            });
        right.setOnAction(e -> {
            if (circle.getCenterX() + 10 + 5 > pane.getWidth()){
                circle.setCenterX(circle.getCenterX()); 
            }
            else 
               circle.setCenterX(circle.getCenterX() + 5);
               circle.setCenterY(circle.getCenterY());
        });
        Scene scene = new Scene(pane, 200, 200);
        primaryStage.setTitle("MoveBall");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
