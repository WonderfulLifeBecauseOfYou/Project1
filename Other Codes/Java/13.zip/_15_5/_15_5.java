import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.HPos;
public class _15_5 extends Application{
	public void start(Stage primaryStage){
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(20, 20, 20, 20));
        pane.setHgap(5);
        pane.setVgap(5);
        TextField tfInvestmentAmount = new TextField();
        TextField tfNumberOfYears = new TextField();
        TextField tfAnnualInterestRate = new TextField();
        TextField tfFutureValue = new TextField();
        Button btCalculate = new Button("Calculate");
        tfInvestmentAmount.setAlignment(Pos.BOTTOM_RIGHT);
        tfNumberOfYears.setAlignment(Pos.BOTTOM_RIGHT);
        tfAnnualInterestRate.setAlignment(Pos.BOTTOM_RIGHT);
        tfFutureValue.setAlignment(Pos.BOTTOM_RIGHT);
        tfFutureValue.setEditable(false);
        GridPane.setHalignment(btCalculate, HPos.RIGHT);
        pane.add(new Label("Investment Amounnt: "), 0 ,0);
        pane.add(tfInvestmentAmount, 1, 0);
        pane.add(new Label("Number Of Years: "), 0, 1);
        pane.add(tfNumberOfYears, 1, 1);
        pane.add(new Label("Annual Iterest Rate: "), 0, 2);
        pane.add(tfAnnualInterestRate, 1, 2);
        pane.add(new Label("Future Value: "), 0, 3);
        pane.add(tfFutureValue, 1, 3);
        pane.add(btCalculate, 1, 4);
        btCalculate.setOnAction(e -> {
            double futureValue = Double.parseDouble(tfInvestmentAmount.getText()) *
                Math.pow((1 + Double.parseDouble(tfAnnualInterestRate.getText()) / 1200), 
                (Integer.parseInt(tfNumberOfYears.getText()) * 12));
            tfFutureValue.setText(String.format("$%.2f", futureValue));
        });
        Scene scene = new Scene(pane);
        primaryStage.setTitle("InvestmentCalculate");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
