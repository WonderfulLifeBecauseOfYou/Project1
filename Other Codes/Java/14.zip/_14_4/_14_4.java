import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class _14_4 extends Application {

public static void main(String[] args) {
    launch(args);
}

public void start(Stage primaryStage) {
    HBox pane = new HBox(15);
    pane.setPadding(new Insets(15, 15, 15, 15));
    for (int i = 0; i < 5; i++)
        pane.getChildren().add(getVBox());

    Scene scene = new Scene(pane);
    primaryStage.setTitle("Wxercise14_04");
    primaryStage.setScene(scene);
    primaryStage.show();
}

public VBox getVBox() {
    VBox pane = new VBox();
    Color color = new  Color(Math.random(), Math.random(), Math.random(), Math.random());
    Text lb = new Text("Java");
    lb.setFont(Font.font("TimesRomes", FontWeight.BOLD, FontPosture.ITALIC, 22));
    lb.setFill(color);
    lb.setRotate(90);
    pane.getChildren().add(lb);
    return pane;
   }
}