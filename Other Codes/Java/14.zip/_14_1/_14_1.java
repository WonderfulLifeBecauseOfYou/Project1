import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class _14_1 extends Application {

public static void main(String[] args) {
	launch(args);
}
public void start(Stage primaryStage) {
	GridPane pane = new GridPane();
	pane.setPadding(new Insets(5, 5, 5, 5));
	pane.setHgap(10);
	pane.setVgap(10);
	ImageView imageView1 = new ImageView("flag2.gif");
	ImageView imageView2 = new ImageView("flag3.gif");
	ImageView imageView3 = new ImageView("flag4.gif");
    ImageView imageView4 = new ImageView("flag6.gif");
	pane.add(imageView1, 0, 0);
	pane.add(imageView2, 0, 1);
	pane.add(imageView3, 1, 1);
	pane.add(imageView4, 1, 1);
	Scene scene = new Scene(pane);
	primaryStage.setTitle("Exercise14_01");
	primaryStage.setScene(scene);
	primaryStage.show();
}
}