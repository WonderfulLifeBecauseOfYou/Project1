/**
 * 
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Polygon;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;
/**
 * @author DELL
 *
 */
public class _14_14 extends Application{
	public void start(Stage primaryStage) {
		Pane pane=new Pane();
		Rectangle r1=new Rectangle(25,10,50,50);
		r1.setStroke(Color.BLACK);
		r1.setFill(Color.WHITE);
		Rectangle r2=new Rectangle(35,5,50,50);
		r2.setStroke(Color.BLACK);
		r2.setFill(Color.WHITE);
		pane.getChildren().addAll(r1,r2);
		Polygon polygon=new Polygon();
		polygon.getPoints().addAll(new Double[] {
				25.0,10.0,
				35.0,5.0,
				85.0,5.0,
				75.0,10.0
		});
		pane.getChildren().add(polygon);
		polygon.setFill(Color.WHITE);
		polygon.setStroke(Color.BLACK);
		
		Scene scene=new Scene(pane);
		primaryStage.setTitle("_14_14");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	

}
