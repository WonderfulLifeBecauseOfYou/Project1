package menubar;

public class Cola extends AbstractDrinks{
	//����
	private String name = "���¿���";
	private double unitprice = 6;
	
	public Cola()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

}
