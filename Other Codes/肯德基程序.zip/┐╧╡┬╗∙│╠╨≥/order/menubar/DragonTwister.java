package menubar;

public class DragonTwister extends AbstractHamburgerChickenRolls{
	//�ϱ��������
	private String name = "�ϱ��������";
	private double unitprice = 18;
	
	public DragonTwister()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

}
