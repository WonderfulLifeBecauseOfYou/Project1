package menubar;

public class MashedPotato extends AbstractSnack{
	//����������
	private String name = "����������";
	private double unitprice = 7;
	
	public MashedPotato()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

}
