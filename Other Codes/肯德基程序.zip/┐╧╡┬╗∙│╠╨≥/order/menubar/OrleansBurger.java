package menubar;

public class OrleansBurger extends AbstractHamburgerChickenRolls{
	//�¶������ȱ�
	private String name = "�¶������ȱ�";
	private double unitprice = 20;
	
	public OrleansBurger()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}
