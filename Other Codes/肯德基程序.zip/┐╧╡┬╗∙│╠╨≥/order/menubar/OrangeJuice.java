package menubar;

public class OrangeJuice extends AbstractDrinks{
	//��֭
	private String name = "�����֭����";
	private double unitprice = 9;
	
	public OrangeJuice()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}
