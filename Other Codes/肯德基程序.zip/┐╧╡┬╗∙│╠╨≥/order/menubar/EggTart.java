package menubar;

public class EggTart extends AbstractSnack{
	//������ʽ��̢
	private String name = "������ʽ��̢";
	private double unitprice = 14;
	
	public EggTart()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}
