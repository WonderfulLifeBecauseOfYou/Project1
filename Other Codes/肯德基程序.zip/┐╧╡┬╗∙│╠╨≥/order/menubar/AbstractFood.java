package menubar;

public abstract class AbstractFood implements Control{
	
	private int num = 0;
	
	public AbstractFood()
	{

	}
	
	public void setNum(int num)
	{
		this.num = num;
	}
	
	public int getNum()
	{
		return num;
	}
	
	public abstract void setUnitPrice(double price);
	public abstract double getUnitPrice();
	public abstract String getName();
	public abstract void setName(String name);
}
