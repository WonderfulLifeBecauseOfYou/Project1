package menubar;

public abstract class AbstractDrinks extends AbstractFood{
	//��Ʒ
	public AbstractDrinks()
	{
		
	}

	public abstract void setUnitPrice(double price);
	public abstract double getUnitPrice();
	public abstract String getName();
	public abstract void setName(String name);
}
