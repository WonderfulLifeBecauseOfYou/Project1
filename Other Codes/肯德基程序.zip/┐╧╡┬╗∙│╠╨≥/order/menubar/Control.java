package menubar;

public interface Control {
	public abstract void setUnitPrice(double price);
	public abstract double getUnitPrice();
	public abstract String getName();
	public abstract void setName(String name);
}
