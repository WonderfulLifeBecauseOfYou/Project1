package menubar;

public abstract class AbstractSnack extends AbstractFood{
	//Сʳ/���
	
	public AbstractSnack()
	{
		
	}

	public abstract void setUnitPrice(double price);
	public abstract double getUnitPrice();
	public abstract String getName();
	public abstract void setName(String name);
}
