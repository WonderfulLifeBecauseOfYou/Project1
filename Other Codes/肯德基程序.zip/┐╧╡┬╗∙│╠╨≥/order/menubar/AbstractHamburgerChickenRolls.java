package menubar;

public abstract class AbstractHamburgerChickenRolls extends AbstractFood{
	//��ζ����/��
	public AbstractHamburgerChickenRolls()
	{
		
	}
	public abstract void setUnitPrice(double price);
	public abstract double getUnitPrice();
	public abstract String getName();
	public abstract void setName(String name);
}
