package menubar;

public class Chips extends AbstractSnack{
	//���ư�������
	private String name = "���ư�������";
	private double unitprice = 14;
	
	public Chips()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}
