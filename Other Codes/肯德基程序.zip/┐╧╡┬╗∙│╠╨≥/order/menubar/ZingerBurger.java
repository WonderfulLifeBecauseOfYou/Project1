package menubar;

public class ZingerBurger extends AbstractHamburgerChickenRolls{
	//�������ȱ�
	private String name = "�������ȱ�";
	private double unitprice = 19.5;
	
	public ZingerBurger()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}
