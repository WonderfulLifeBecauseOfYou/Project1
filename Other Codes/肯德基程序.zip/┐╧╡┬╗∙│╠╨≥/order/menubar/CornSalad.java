package menubar;

public class CornSalad extends AbstractSnack{
	//����ɳ��
	private String name = "�߲�ˮ��ɳ��";
	private double unitprice = 8;
	
	public CornSalad()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

}
