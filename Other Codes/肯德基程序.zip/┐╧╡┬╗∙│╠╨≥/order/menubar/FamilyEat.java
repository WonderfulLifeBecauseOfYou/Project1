package menubar;

public class FamilyEat extends AbstractSnack{
	//ȫ��Ͱ
	private String name = "ȫ��Ͱ";
	private double unitprice = 36;
	
	public FamilyEat()
	{
		
	}
	
	public void setUnitPrice(double price)
	{
		this.unitprice = price;
	}
	
	public double getUnitPrice()
	{
		return unitprice;
	}
	
	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}
}