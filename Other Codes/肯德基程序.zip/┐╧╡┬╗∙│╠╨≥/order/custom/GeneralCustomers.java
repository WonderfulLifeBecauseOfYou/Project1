package custom;

public class GeneralCustomers extends Customer//��ͨ�˿�
{
	public GeneralCustomers()
	{
		this.setDiscount(10);
		this.setName("��ͨ�˿�");
	}
	
}
