package custom;

public class InternalStaff extends Customer//�ڲ�Ա��
{
	public InternalStaff()
	{
		this.setDiscount(7.5);
		this.setName("�ڲ�Ա��");
	}
}
