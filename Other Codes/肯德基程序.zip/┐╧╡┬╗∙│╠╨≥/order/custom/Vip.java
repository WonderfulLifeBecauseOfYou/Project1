package custom;

public class Vip extends Customer//VIP�˿�
{
	public Vip()
	{
		this.setDiscount(8);
		this.setName("VIP�˿�");
	}
}
