package control;
 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import custom.Customer;
import menubar.AbstractFood;

public class FileRD {
	
	public void method1(String filepath , String content)//����д���ļ�
	{
        FileWriter fw = null;
        try {//����ļ����ڣ���׷�����ݣ�����ļ������ڣ��򴴽��ļ�
                File f=new File(filepath);
                fw = new FileWriter(f, true);
        } catch (IOException e) {
                e.printStackTrace();
        }
        PrintWriter pw = new PrintWriter(fw);
        pw.println(content);
        pw.flush();
        try {
                fw.flush();
                pw.close();
                fw.close();
        } catch (IOException e) {
                e.printStackTrace();
        }
	}
	public void initPriceAndDiscount(ArrayList<AbstractFood> foods,ArrayList<String> foodName,ArrayList<Customer> customer,String filepath)
	{
		try {
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							new FileInputStream(filepath)));
			String line;
			while((line=in.readLine())!=null)
			{
				for(int i=0;i<9;i++)
				{
					if(line.contains(foodName.get(i)))
					{
						foods.get(i).setUnitPrice(Double.valueOf(line.substring(line.indexOf(":")+1)));
						break;
					}
				}
				if(line.contains("---"))
					break;
			}
			while((line=in.readLine())!=null)
			{
				for(int i=0;i<3;i++)
				{
					if(line.contains(customer.get(i).getName()))
					{
						customer.get(i).setDiscount(Double.valueOf(line.substring(line.indexOf(":")+1)));
						break;
					}
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
	}
	public void changefile(ArrayList<AbstractFood> foods,ArrayList<String> foodName,ArrayList<Customer> customer,String filepath)
	{
		FileWriter fw = null;
        try {
                File f=new File(filepath);
                fw = new FileWriter(f);
                PrintWriter pw = new PrintWriter(fw);
                for(int i=0;i<9;i++)
                {
                	pw.println(foodName.get(i)+":"+foods.get(i).getUnitPrice());
                }
                pw.println("-----------");
                for(int i=0;i<3;i++)
                {
                	pw.println(customer.get(i).getName()+":"+customer.get(i).getDiscount());
                }
    	        
    	        fw.close();
        } catch (IOException e) {
                e.printStackTrace();
        }       
	}
	public String calculateAmount(String filepath)//���ÿ���ͻ���ƽ�����۶�
	{
		String s ="";
		try {
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							new FileInputStream(filepath)));
			double amount=0;
			int n = 0;
			String line;
			while((line=in.readLine())!=null)
			{
				if(line.contains("ʵ����"))
				{
					n++;
					int index = line.indexOf("ʵ����");
					double price = Double.valueOf(line.substring(index+5));
					amount+=price;
				}
			}
			s = "��ˮ�ܽ��:"+amount+"	"+"����������:"+n+"\n�˾����Ѷ"+amount/n+"\n\n";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		return s;
	}
	public String calculateAmount1(String filepath)//���ÿ���ͻ���ƽ�����۶�
	{
		String s ="";
		double[] amount = new double[3];
		int[] n = new int[3];
		for(int i=0;i<3;i++)
			n[i] = 0;
		try {
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							new FileInputStream(filepath)));
			String line;
			while((line=in.readLine())!=null)
			{
				if(line.contains("��ͨ�˿�"))
				{
					while(!line.contains("ʵ����"))
					{
						line=in.readLine();
					}
					int index = line.indexOf("ʵ����");
					double price = Double.valueOf(line.substring(index+5));
					amount[0] += price;
					n[0]++;
				}
				else if(line.contains("VIP�˿�"))
				{
					while(!line.contains("ʵ����"))
					{
						line=in.readLine();
					}
					int index = line.indexOf("ʵ����");
					double price = Double.valueOf(line.substring(index+5));
					amount[1] += price;
					n[1]++;
				}
				else if(line.contains("�ڲ�Ա��"))
				{
					while(!line.contains("ʵ����"))
					{
						line=in.readLine();
					}
					int index = line.indexOf("ʵ����");
					double price = Double.valueOf(line.substring(index+5));
					amount[2] += price;
					n[2]++;
				}
			}
			s = "��ͨ�˿������ܽ��"+amount[0]+"	"+"��ͨ�˿������ܴ���:"+n[0]+"\n��ͨ�˿��˾����Ѷ"+amount[0]/n[0]+"\n\n"
					+"VIP�˿������ܽ��"+amount[1]+"	"+"VIP�˿������ܴ���:"+n[1]+"\nVIP�˿��˾����Ѷ"+amount[1]/n[1]+"\n\n"
					+"�ڲ�Ա�������ܽ��"+amount[2]+"	"+"�ڲ�Ա�������ܴ���:"+n[2]+"\n�ڲ�Ա���˾����Ѷ"+amount[2]/n[2]+"\n\n";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		return s;
	}
	public String calculateItemQuantity(String filepath,ArrayList<String> foodName)//���һ����൥Ʒ���������
	{
		String s = "";
		int[] numOfFood = new int[9];
		for(int i=0;i<9;i++)
			numOfFood[i] = 0;
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date(System.currentTimeMillis());
		String data = formatter.format(date);
		try {
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							new FileInputStream(filepath)));
			String line;
			while((line=in.readLine())!=null)
			{
				if(line.contains(data))//����Ǳ���
				{
					while(!(line=in.readLine()).contains("---"))
					{
						int n;
						for(int i=0;i<9;i++)
						{
							if(line.contains(foodName.get(i)+""))
							{
								n = Integer.valueOf(line.substring(line.indexOf("*")+1));
								numOfFood[i] += n;
								break;
							}
						}
					}
				}
			}
			for(int i=0;i<9;i++)
			{
				s += foodName.get(i)+":"+numOfFood[i]+"��\n";
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 catch (IOException e) {
			// TODO Auto-generated catch block 
			e.printStackTrace();
		}
		return s;
	}
}
