package control;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import custom.Customer;
import menubar.AbstractFood;

public class ShoppingCart {
	private int[] cashier = new int[6];
	
	Customer customer = new Customer();
	
	public ArrayList<AbstractFood> foods = new ArrayList<AbstractFood>();
	public ArrayList<String> foodName = new ArrayList<String>();
	public ArrayList<Integer> foodNum = new ArrayList<Integer>();
	public ArrayList<Double> foodPrice = new ArrayList<Double>();
	
	public ShoppingCart()
	{
		
	}
	
	public ShoppingCart(ArrayList foods,ArrayList foodName,Customer customer)
	{
		this.foods = foods;
		this.foodName = foodName;
		this.customer = customer;
		
		for(int i=0;i<6;i++)
		{
			cashier[i] = 10001+i;
		}
	}
	public String OpeningBills() //��Ʊ��
	{
		String inform = "";
		double accounts = 0;
		double actualPayment = 0;

		for(int i=0;i<foods.size();i++)
		{
			foodPrice.add(foods.get(i).getUnitPrice());
			foodNum.add(foods.get(i).getNum());
		}
		
		SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd   HH:mm:ss z");
		Date date = new Date(System.currentTimeMillis());
		int clock = Integer.valueOf(formatter.format(date).substring(13,15));
		inform += formatter.format(date)+"\n";
		inform += "������:"+customer.getName()+"	"+"����Ա:"+cashier[clock/4]+"\n";
		for(int i=0;i<foods.size();i++)
		{
			if(foodNum.get(i)>0)
			{
				inform += foodName.get(i)+"    "+foodPrice.get(i)+"*"+foodNum.get(i)+"\n";
				accounts += foodPrice.get(i)*foodNum.get(i);
			}	
		}
		actualPayment = accounts*this.customer.getDiscount()*0.1;
		
		inform += "�ۿۣ�"+this.customer.getDiscount()+"��"+"\n";
		inform += "Ӧ�����"+accounts+"	"+"ʵ�����"+actualPayment+"\n";
		inform += "-------------------------------------------------";
		return inform;
	}
	
	public void ClearCache()//������ﳵ����
	{
		for(int i=0;i<foods.size();i++)
		{
			foods.get(i).setNum(0);
		}
		foodPrice.clear();
		foodNum.clear();
	}
	
	public void setZingerBurgerNum(int num)
	{
		foods.get(0).setNum(num);
	}
	public void setOrleansBurgerNum(int num)
	{
		foods.get(1).setNum(num);
	}
	public void setDragonTwisterNum(int num)
	{
		foods.get(2).setNum(num);
	}
	public void setEggTartNum(int num)
	{
		foods.get(3).setNum(num);
	}
	public void setChipsNum(int num)
	{
		foods.get(4).setNum(num);
	}
	public void setCornSaladNum(int num)
	{
		foods.get(5).setNum(num);
	}
	public void setMashedPotatoNum(int num)
	{
		foods.get(6).setNum(num);
	}
	public void setColaNum(int num)
	{
		foods.get(7).setNum(num);
	}
	public void setOrangeJuiceNum(int num)
	{
		foods.get(8).setNum(num);
	}
	
}
