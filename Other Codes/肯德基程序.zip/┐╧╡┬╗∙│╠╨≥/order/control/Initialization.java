package control;

import java.util.ArrayList;
import java.util.Scanner;
import custom.*;
import menubar.*;

public class Initialization {

	ArrayList<String> foodName = new ArrayList<String>();//����
	ArrayList<AbstractFood> foods = new ArrayList<AbstractFood>();//�˵�
	ArrayList<Customer> customer = new ArrayList<Customer>();//����
	Customer generalCustomers,vip,internalStaff;//��ͬ���͵Ĺ˿�
	ShoppingCart shoppingCartGeneral,shoppingCartVip,shoppingCartStaff;//��ͬ���͹˿͵Ĺ��ﳵ

	FileRD fileRD = new FileRD();//�ļ���
	String filepath1 = "inform.txt";//�ļ�·��1
	String filepath2 = "PriceAndDiscount.txt";//�ļ�·��2

	AbstractHamburgerChickenRolls zingerBurger = new ZingerBurger();
	AbstractHamburgerChickenRolls orleansBurger = new OrleansBurger();
	AbstractHamburgerChickenRolls dragonTwister = new DragonTwister();
	AbstractSnack eggTart = new EggTart();
	AbstractSnack chips = new Chips();
	AbstractSnack cornSalad = new CornSalad();
	AbstractSnack mashedPotato = new MashedPotato();
	AbstractDrinks cola = new Cola(); 
	AbstractDrinks orangeJuice = new OrangeJuice();

	
	public void init()//���ݳ�ʼ��
	{
		foods.add(zingerBurger);
		foods.add(orleansBurger);
		foods.add(dragonTwister);
		foods.add(eggTart);
		foods.add(chips);
		foods.add(cornSalad);
		foods.add(mashedPotato);
		foods.add(cola);
		foods.add(orangeJuice);
		
		foodName.add("�������ȱ�");		foodName.add("�¶��������ȱ�");		foodName.add("�ϱ��������");	
		foodName.add("������ʽ��̢");		foodName.add("���ư�������");		foodName.add("�߲�ˮ��ɳ��");
		foodName.add("����������");		foodName.add("���¿���");			foodName.add("�����֭����");
		
		generalCustomers = new GeneralCustomers();//��ͨ�˿�
		vip = new Vip();//VIP�˿�
		internalStaff = new InternalStaff();//�ڲ�Ա��
		customer.add(generalCustomers);	customer.add(vip);	customer.add(internalStaff);
		fileRD.initPriceAndDiscount(foods, foodName, customer, filepath2);
		
		shoppingCartGeneral = new ShoppingCart(foods,foodName,generalCustomers);
		shoppingCartVip = new ShoppingCart(foods,foodName,vip);
		shoppingCartStaff = new ShoppingCart(foods,foodName,internalStaff);
	}
	
	public ArrayList<String> getfoodName() {
		return foodName;
	}
	
	public ArrayList<AbstractFood> getFoods() {
		return foods;
	}
	
	public ArrayList<Customer> getCustomer() {
		return customer;
	}

	public void setFoods(ArrayList<AbstractFood> foods) {
		this.foods = foods;
	}

	public ShoppingCart getShoppingCartGeneral() {
		return shoppingCartGeneral;
	}

	public ShoppingCart getShoppingCartVip() {
		return shoppingCartVip;
	}

	public ShoppingCart getShoppingCartStaff() {
		return shoppingCartStaff;
	}
	
	public FileRD getFileRD() {
		return fileRD;
	}

	public void setFileRD(FileRD fileRD) {
		this.fileRD = fileRD;
	}

	public String getFilepath1() {
		return filepath1;
	}

	public void setFilepath1(String filepath1) {
		this.filepath1 = filepath1;
	}
	
	public String getFilepath2() {
		return filepath2;
	}

	public void setFilepath2(String filepath2) {
		this.filepath2 = filepath2;
	}

}
