package view;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import menubar.AbstractFood;
import control.*;

public class Test extends Application {

	int flag = 0;
	int t;
	int x;
	int y;
	String inform = "";
	double accounts = 0;
	double actualPayment = 0;
	int[] foodNumber = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) {
		Initialization Init = new Initialization();
		Init.init();
		AlertWindow alertWindow = new AlertWindow();
		/*-----------------------ͼƬ-----------------------*/
		Image image1 = new Image("1.jpg");
		ImageView imageview1 = new ImageView(image1);
		Image image2 = new Image("2.jpg");
		ImageView imageview2 = new ImageView(image2);
		Image image3 = new Image("3.jpeg");
		ImageView imageview3 = new ImageView(image3);
		ImageView imageview4 = new ImageView(image3);

		Image food1 = new Image("�������ȱ�.jpg");
		ImageView foodOne = new ImageView(food1);
		Image food2 = new Image("�¶������ȱ�.jpg");
		ImageView foodTwo = new ImageView(food2);
		Image food3 = new Image("�ϱ��������.jpg");
		ImageView foodThree = new ImageView(food3);
		Image food4 = new Image("������ʽ��̢.jpg");
		ImageView foodFour = new ImageView(food4);
		Image food5 = new Image("���ư�������.jpg");
		ImageView foodFive = new ImageView(food5);
		Image food6 = new Image("�߲�ˮ��ɳ��.jpg");
		ImageView foodSix = new ImageView(food6);
		Image food7 = new Image("����������.jpg");
		ImageView foodSeven = new ImageView(food7);
		Image food8 = new Image("���¿���.jpg");
		ImageView foodEight = new ImageView(food8);
		Image food9 = new Image("�����֭����.jpg");
		ImageView foodNine = new ImageView(food9);
		Image food10 = new Image("ȫ��Ͱ.jpg");
		ImageView foodTen = new ImageView(food10);

		/*-----------------------������-----------------------*/
		StackPane pane1 = new StackPane();
		Button general = new Button("1.��ͨ�˿͵��");
		Button vip = new Button("2.VIP�˿͵��");
		Button staff = new Button("3.�ڲ�Ա�����");
		Button setUp = new Button("4.ϵͳ����");
		Button query = new Button("5.��ѯ");
		Button exitSystem = new Button("6.�˳�ϵͳ");
		VBox mainMenu = new VBox();
		mainMenu.setAlignment(Pos.CENTER);// �ڵ���з���
		mainMenu.setSpacing(40);// �ڵ��е�Ԫ�ؼ��40
		mainMenu.getChildren().addAll(general, vip, staff, setUp, query, exitSystem);
		pane1.getChildren().add(imageview1);
		pane1.getChildren().add(mainMenu);
		Scene scene1 = new Scene(pane1);

		/*-----------------------�㵥����-----------------------*/
		StackPane pane2 = new StackPane();
		Button pay = new Button("֧��");
		Button goBackScene1 = new Button("����");
		Button bot5 = new Button("���ﳵ");
		GridPane gridpane = new GridPane();
		gridpane.setAlignment(Pos.CENTER);
		VBox vbox1 = new VBox();
		Label label1 = new Label("�������ȱ�");
		label1.setFont(Font.font("����", FontWeight.BOLD, 20));// �����ı����塢�Ӵ֡���С
		vbox1.getChildren().addAll(label1, foodOne);
		VBox vbox2 = new VBox();
		Label label2 = new Label("�¶������ȱ�");
		label2.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox2.getChildren().addAll(label2, foodTwo);
		VBox vbox3 = new VBox();
		Label label3 = new Label("�ϱ��������");
		label3.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox3.getChildren().addAll(label3, foodThree);
		VBox vbox4 = new VBox();
		Label label4 = new Label("������ʽ��̢");
		label4.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox4.getChildren().addAll(label4, foodFour);
		VBox vbox5 = new VBox();
		Label label5 = new Label("���ư�������");
		label5.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox5.getChildren().addAll(label5, foodFive);
		VBox vbox6 = new VBox();
		Label label6 = new Label("�߲�ˮ��ɳ��");
		label6.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox6.getChildren().addAll(label6, foodSix);
		VBox vbox7 = new VBox();
		Label label7 = new Label("����������");
		label7.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox7.getChildren().addAll(label7, foodSeven);
		VBox vbox8 = new VBox();
		Label label8 = new Label("���¿���");
		label8.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox8.getChildren().addAll(label8, foodEight);
		VBox vbox9 = new VBox();
		Label label9 = new Label("�����֭����");
		label9.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox9.getChildren().addAll(label9, foodNine);
		VBox vbox10 = new VBox();
		Label label10 = new Label("ȫ��Ͱ");
		label10.setFont(Font.font("����", FontWeight.BOLD, 20));
		vbox10.getChildren().addAll(label10, foodTen);
		gridpane.add(vbox1, 0, 0);
		gridpane.add(vbox2, 1, 0);
		gridpane.add(vbox3, 2, 0);
		gridpane.add(vbox4, 3, 0);
		gridpane.add(vbox5, 4, 0);
		gridpane.add(vbox6, 0, 1);
		gridpane.add(vbox7, 1, 1);
		gridpane.add(vbox8, 2, 1);
		gridpane.add(vbox9, 3, 1);
		gridpane.add(vbox10, 4, 1);
		gridpane.add(pay, 4, 4);
		gridpane.add(goBackScene1, 0, 4);
		gridpane.add(bot5, 2, 4);
		gridpane.setHgap(10);
		gridpane.setVgap(10);
		pane2.getChildren().add(imageview2);
		pane2.getChildren().add(gridpane);
		Scene scene2 = new Scene(pane2);
		foodOne.setOnMouseClicked(e -> {
			alertWindow.display("�������ȱ�");
			int n = alertWindow.getNum();
			if (n != 0) {
				t = 1;
				y = n;
			}
			System.out.println(n);
			System.out.println(y);
			System.out.println(t);
			if (flag == 1)
				Init.getShoppingCartGeneral().setZingerBurgerNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setZingerBurgerNum(n);
			else if (flag == 3) {
				Init.getShoppingCartStaff().setZingerBurgerNum(n);
			}

		});
		foodTwo.setOnMouseClicked(e -> {
			System.out.println(y);
			System.out.println(t);
			alertWindow.display("�¶������ȱ�");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setOrleansBurgerNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setOrleansBurgerNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setOrleansBurgerNum(n);
			if (n != 0) {
				t = 2;
				y = n;
			}
			System.out.println(n);
			System.out.println(y);
			System.out.println(t);

		});
		foodThree.setOnMouseClicked(e -> {

			alertWindow.display("�ϱ��������");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setDragonTwisterNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setDragonTwisterNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setDragonTwisterNum(n);
			if (n != 0) {
				t = 3;
				y = n;
			}

		});
		foodFour.setOnMouseClicked(e -> {

			alertWindow.display("������ʽ��̢");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setEggTartNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setEggTartNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setEggTartNum(n);
		});
		foodFive.setOnMouseClicked(e -> {

			alertWindow.display("���ư�������");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setChipsNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setChipsNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setChipsNum(n);

		});
		foodSix.setOnMouseClicked(e -> {

			alertWindow.display("�߲�ˮ��ɳ��");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setCornSaladNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setCornSaladNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setCornSaladNum(n);
			if (n != 0) {
				t = 6;
				y = n;
			}

		});
		foodSeven.setOnMouseClicked(e -> {

			alertWindow.display("����������");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setMashedPotatoNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setMashedPotatoNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setMashedPotatoNum(n);
			if (n != 0) {
				t = 7;
				y = n;
			}

		});
		foodEight.setOnMouseClicked(e -> {

			alertWindow.display("���¿���");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setColaNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setColaNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setColaNum(n);
			if (n != 0) {
				t = 8;
				y = n;
			}

		});
		foodNine.setOnMouseClicked(e -> {

			alertWindow.display("�����֭����");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setOrangeJuiceNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setOrangeJuiceNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setOrangeJuiceNum(n);
			if (n != 0) {
				t = 9;
				y = n;
			}

		});
		foodTen.setOnMouseClicked(e -> {

			alertWindow.display("ȫ��Ͱ");
			int n = alertWindow.getNum();
			if (flag == 1)
				Init.getShoppingCartGeneral().setZingerBurgerNum(n);
			else if (flag == 2)
				Init.getShoppingCartVip().setZingerBurgerNum(n);
			else if (flag == 3)
				Init.getShoppingCartStaff().setZingerBurgerNum(n);
			if (n != 0) {
				t = 10;
				y = n;
			}
		});

		pay.setOnAction((ActionEvent e) -> {
			String inform = "";
			if (flag == 1) {
				inform = Init.getShoppingCartGeneral().OpeningBills();// ���ɲ͵���
				alertWindow.output(inform);// ��ӡ����͵���
				Init.getFileRD().method1(Init.getFilepath1(), inform);
				Init.getShoppingCartGeneral().ClearCache();// ������ﳵ����
			} else if (flag == 2) {
				inform = Init.getShoppingCartVip().OpeningBills();// ���ɲ͵���
				alertWindow.output(inform);// ��ӡ����͵���
				Init.getFileRD().method1(Init.getFilepath1(), inform);
				Init.getShoppingCartVip().ClearCache();// ������ﳵ����
			} else if (flag == 3) {
				inform = Init.getShoppingCartStaff().OpeningBills();// ���ɲ͵���
				alertWindow.output(inform);// ��ӡ����͵���
				Init.getFileRD().method1(Init.getFilepath1(), inform);
				Init.getShoppingCartStaff().ClearCache();// ������ﳵ����
			}
			flag = 0;
			primaryStage.setScene(scene1);
		});
		goBackScene1.setOnAction((ActionEvent e) -> {
			if (flag == 1)
				Init.getShoppingCartGeneral().ClearCache();// ������ﳵ����
			else if (flag == 2)
				Init.getShoppingCartVip().ClearCache();// ������ﳵ����
			else if (flag == 3)
				Init.getShoppingCartStaff().ClearCache();// ������ﳵ����

			flag = 0;
			primaryStage.setScene(scene1);
		});

		/*-----------------------���ﳵ����-----------------------*/
		StackPane pane5 = new StackPane();
		Button bot1 = new Button("+");
		Button bot2 = new Button("-");
		Button bot3 = new Button("ȷ��");
		Button bot4 = new Button("����");
		HBox hbox10 = new HBox();
		HBox hbox20 = new HBox();
		VBox vbox20 = new VBox();
		vbox20.setPadding(new Insets(250));
		hbox20.getChildren().addAll(bot3, bot4);
		AbstractFood tex =Init.getShoppingCartGeneral().foods.get(y);
		String text = Init.getShoppingCartGeneral().foodName.get(y);
		Double textt = Init.getShoppingCartGeneral().foodPrice.get(y);
		Integer texttt = Init.getShoppingCartGeneral().foodNum.get(y);
		for(int i=0;i<y;i++)
		{
			if(texttt>0)
			{
				inform += text+"    "+textt+"*"+texttt+"\n";
				accounts += textt*texttt;
			}	
		}
		if (text == "�������ȱ�") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		}
		if (text == "�¶������ȱ�") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "���¿���") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "���ư�������") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "����������") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "������ʽ��̢") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "�����֭����") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "�ϱ��������") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "ȫ��Ͱ") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} 
		if (text == "�߲�ˮ��ɳ��") {
			Text text1 = new Text(text + "" + textt + "*" + "" + texttt);
			hbox10.getChildren().addAll(text1);
		} else {
			Text text1 = new Text("������ͣ�");
			hbox10.getChildren().addAll(text1);
		}
		vbox20.getChildren().addAll(hbox10, hbox20);
		pane5.getChildren().add(vbox20);
		Scene scene5 = new Scene(pane5);

		/*-----------------------���ý���-----------------------*/
		StackPane pane3 = new StackPane();
		Button priceRevision = new Button("�޸ļ۸�");
		Button modifyDiscount = new Button("�޸��ۿ�");
		Button goBack1 = new Button("����");
		VBox modifyAttribute = new VBox();
		modifyAttribute.setAlignment(Pos.CENTER);
		modifyAttribute.setSpacing(40);
		modifyAttribute.getChildren().addAll(priceRevision, modifyDiscount, goBack1);
		pane3.getChildren().add(imageview3);
		pane3.getChildren().add(modifyAttribute);
		Scene scene3 = new Scene(pane3);

		priceRevision.setOnAction((ActionEvent e) -> {// �޸ĵ�Ʒ�۸�
			alertWindow.changePrice(Init);
			int n = alertWindow.getFlag();
			if (n != -1)
				alertWindow.judge(n);
		});
		modifyDiscount.setOnAction((ActionEvent e) -> {// �޸��ۿ�
			alertWindow.changeDiscount(Init);
			int n = alertWindow.getFlag();
			if (n != -1)
				alertWindow.judge(n);
		});
		goBack1.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene1);
		});

		/*-----------------------��ѯ����-----------------------*/
		StackPane pane4 = new StackPane();
		Button outputItemQuantity = new Button("��ѯһ����൥Ʒ���������");
		Button salesVolume = new Button("��ѯ���۶�");
		Button goBack2 = new Button("����");
		VBox queryData = new VBox();
		queryData.setAlignment(Pos.CENTER);
		queryData.setSpacing(40);
		queryData.getChildren().addAll(outputItemQuantity, salesVolume, goBack2);
		pane4.getChildren().add(imageview4);
		pane4.getChildren().add(queryData);
		Scene scene4 = new Scene(pane4);

		outputItemQuantity.setOnAction((ActionEvent e) -> {
			String s = Init.getFileRD().calculateItemQuantity(Init.getFilepath1(), Init.getfoodName());
			alertWindow.output(s);
		});
		salesVolume.setOnAction((ActionEvent e) -> {
			String s1 = Init.getFileRD().calculateAmount(Init.getFilepath1());
			String s2 = Init.getFileRD().calculateAmount1(Init.getFilepath1());
			alertWindow.output(s1 + s2);
		});
		goBack2.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene1);
		});

		/*-----------------------�����ť-----------------------*/
		general.setOnAction((ActionEvent e) -> {
			flag = 1;
			primaryStage.setScene(scene2);
		});
		vip.setOnAction((ActionEvent e) -> {
			flag = 2;
			primaryStage.setScene(scene2);
		});
		staff.setOnAction((ActionEvent e) -> {
			flag = 3;
			primaryStage.setScene(scene2);
		});
		setUp.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene3);
		});
		query.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene4);
		});
		exitSystem.setOnAction((ActionEvent e) -> {
			Init.getFileRD().changefile(Init.getFoods(), Init.getfoodName(), Init.getCustomer(), Init.getFilepath2());
			primaryStage.close();
		});
		bot5.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene5);
		});
		bot3.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene2);
		});
		bot4.setOnAction((ActionEvent e) -> {
			primaryStage.setScene(scene2);
		});

		/*--------------------------------------------------*/
		primaryStage.setTitle("���ϵͳ");// ��̨����
		primaryStage.setScene(scene1);// ���������뵽��̨��
		primaryStage.show();

	}

}
